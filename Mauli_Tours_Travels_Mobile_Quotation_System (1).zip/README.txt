MAULI TOURS & TRAVELS — MOBILE QUOTATION SYSTEM

How it works:
1. Open index.html in a browser (or deploy this folder to Vercel/GitHub).
2. Fill customer and trip details.
3. Tap Generate Quotation PDF.
4. The PDF downloads to the phone and can be shared on WhatsApp.
5. Drafts can be saved locally on the same phone.

Important:
- The PDF generator uses jsPDF from a CDN, so the first PDF generation needs internet access.
- Customer information is kept in the browser unless you choose to send the generated PDF yourself.
- The quotation number is generated automatically on that device.
